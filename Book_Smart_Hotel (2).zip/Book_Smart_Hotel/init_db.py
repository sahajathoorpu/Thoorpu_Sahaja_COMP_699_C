import sqlite3

from flask_sqlalchemy import SQLAlchemy


def init_db():
    conn = sqlite3.connect('instance/booksmart.db')
    c = conn.cursor()

    # Create users table if not exists
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            phone TEXT,
            points INTEGER DEFAULT 0
        )
    ''')

    # Create saved_hotels table
    c.execute('''
        CREATE TABLE IF NOT EXISTS saved_hotels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            hotel_id INTEGER,
            saved_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, hotel_id)
        )
    ''')

    # Create admin table
    c.execute('''
        CREATE TABLE IF NOT EXISTS admin (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')

    # Create hotel table with available_rooms
    c.execute('''
        CREATE TABLE IF NOT EXISTS hotel (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            location TEXT NOT NULL,
            total_rooms INTEGER NOT NULL,
            available_rooms INTEGER,
            price_per_night FLOAT NOT NULL,
            amenities TEXT,
            admin_id INTEGER NOT NULL,
            FOREIGN KEY (admin_id) REFERENCES admin (id)
        )
    ''')

    # Create bookings table 
    c.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hotel_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            room_number INTEGER,
            check_in DATETIME NOT NULL,
            check_out DATETIME NOT NULL,
            status TEXT DEFAULT 'pending',
            payment_status TEXT DEFAULT 'pending',
            early_checkin BOOLEAN DEFAULT 0,
            total_amount FLOAT NOT NULL,
            flagged BOOLEAN DEFAULT 0,
            flag_reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (hotel_id) REFERENCES hotel (id),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
