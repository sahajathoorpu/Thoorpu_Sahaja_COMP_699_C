from flask import Blueprint, flash, redirect, render_template, request, session, url_for, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from .models import Admin, Hotel, Booking, db
from .views import hotel_database
import sqlite3

admin = Blueprint('admin', __name__)

@admin.route('/admin/auth', methods=['GET'])
def admin_auth():
    if 'admin_id' in session:
        return redirect(url_for('admin.dashboard'))
    return render_template('admin_auth.html')

@admin.route('/admin/login', methods=['POST'])
def admin_login():
    email = request.form['email']
    password = request.form['password']
    
    admin_user = Admin.query.filter_by(email=email).first()
    if admin_user and check_password_hash(admin_user.password, password):
        session['admin_id'] = admin_user.id
        session['admin_email'] = admin_user.email
        return_url = redirect(url_for('admin.dashboard'))
        flash('Successfully logged in!')
        return return_url
    
    flash("Invalid email or password")
    return redirect(url_for('admin.admin_auth'))

@admin.route('/admin/signup', methods=['GET', 'POST'])
def admin_signup():
    if request.method == 'GET':
        return render_template('admin_auth.html')

    email = request.form['email']
    password = request.form['password']

    existing_admin = Admin.query.filter_by(email=email).first()
    if existing_admin:
        flash("Email already registered")
        return redirect(url_for('admin.admin_auth'))

    hashed_password = generate_password_hash(password)
    new_admin = Admin(email=email, password=hashed_password)

    try:
        db.session.add(new_admin)
        db.session.commit()
        flash("Account created successfully! Please log in.")
    except Exception as e:
        db.session.rollback()
        flash("An error occurred. Please try again.")

    return redirect(url_for('admin.admin_auth'))

@admin.route('/admin/add_hotel', methods=['POST'])
def add_hotel():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    
    name = request.form.get('name')
    location = request.form.get('location')
    total_rooms = request.form.get('total_rooms')
    price_per_night = request.form.get('price_per_night')
    amenities = request.form.get('amenities')
    
    new_hotel = Hotel(
        name=name,
        location=location,
        total_rooms=total_rooms,
        price_per_night=price_per_night,
        amenities=amenities,
        admin_id=session['admin_id']
    )
    
    db.session.add(new_hotel)
    db.session.commit()
    
    flash('Property added successfully!')
    return redirect(url_for('admin.dashboard'))

@admin.route('/admin/dashboard')
def dashboard():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))

    status_filter = request.args.get('status', 'all')
    hotels = Hotel.query.filter_by(admin_id=session['admin_id']).all()
    
    bookings_query = Booking.query.join(Hotel).filter(Hotel.admin_id == session['admin_id'])
    if status_filter != 'all':
        bookings_query = bookings_query.filter(Booking.status == status_filter)
    
    bookings = bookings_query.order_by(Booking.created_at.desc()).all()
    return render_template('admin_dashboard.html', hotels=hotels, bookings=bookings)

@admin.route('/admin/assign-room/<int:booking_id>', methods=['POST'])
def assign_room(booking_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    booking = Booking.query.get_or_404(booking_id)
    booking.room_number = data['room_number']
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/update-status/<int:booking_id>', methods=['POST'])
def update_booking_status(booking_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    booking = Booking.query.get_or_404(booking_id)
    booking.status = data['status']
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/process-refund/<int:booking_id>', methods=['POST'])
def process_refund(booking_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    booking = Booking.query.get_or_404(booking_id)
    booking.status = 'cancelled'
    booking.payment_status = 'refunded'
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/flag-booking/<int:booking_id>', methods=['POST'])
def flag_booking(booking_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    booking = Booking.query.get_or_404(booking_id)
    booking.flagged = True
    booking.flag_reason = data['reason']
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/update-availability/<int:hotel_id>', methods=['POST'])
def update_availability(hotel_id):
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    hotel = Hotel.query.get_or_404(hotel_id)
    hotel.available_rooms = int(data['available_rooms'])
    db.session.commit()
    return jsonify({'success': True})

    # Get total bookings
    try:
        cur.execute("SELECT COUNT(*) FROM bookings")
        total_bookings = cur.fetchone()[0] or 0
    except sqlite3.OperationalError:
        total_bookings = 0

    # Get recent bookings
    cur.execute("""
        SELECT b.id, u.name, b.hotel_id, b.checkin, b.checkout, b.status 
        FROM bookings b 
        LEFT JOIN users u ON b.user_id = u.id 
        ORDER BY b.id DESC LIMIT 5
    """)
    recent_bookings = [{
        'id': row[0],
        'guest_name': row[1],
        'hotel_id': row[2],
        'check_in': row[3],
        'check_out': row[4],
        'status': row[5] or 'pending'
    } for row in cur.fetchall()]

    conn.close()

    dashboard_data = {
        'total_bookings': total_bookings,
        'available_rooms': 45,  # This could be calculated from your hotel database
        'active_promotions': 3,
        'recent_bookings': recent_bookings,
        'hotels': hotel_database  # Add hotel database to dashboard
    }

    return render_template('admin_dashboard.html', **dashboard_data)

@admin.route('/admin/rates-availability')
def rates_availability():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    
    hotels = Hotel.query.filter_by(admin_id=session['admin_id']).all()
    rates = db.session.query(Hotel).filter_by(admin_id=session['admin_id']).all()
    return render_template('admin_rates.html', hotels=hotels, rates=rates)

@admin.route('/admin/update-rate', methods=['POST'])
def update_rate():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    rate_id = data.get('rate_id')
    new_rate = data.get('new_rate')
    
    hotel = Hotel.query.get_or_404(rate_id)
    if hotel.admin_id != session['admin_id']:
        return jsonify({'error': 'Unauthorized'}), 401
    
    hotel.price_per_night = new_rate
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/bulk-update-rates', methods=['POST'])
def bulk_update_rates():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    adjustment_type = data.get('adjustment_type')
    adjustment_value = float(data.get('adjustment_value'))
    
    hotels = Hotel.query.filter_by(admin_id=session['admin_id']).all()
    
    for hotel in hotels:
        if adjustment_type == 'percentage':
            hotel.price_per_night *= (1 + adjustment_value/100)
        else:
            hotel.price_per_night += adjustment_value
    
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/reservations')
def reservations():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    
    status = request.args.get('status', '')
    date = request.args.get('date', '')
    search = request.args.get('search', '')
    
    query = Booking.query.join(Hotel).filter(Hotel.admin_id == session['admin_id'])
    
    if status:
        query = query.filter(Booking.status == status)
    if date:
        query = query.filter(Booking.checkin == date)
    if search:
        query = query.filter(
            (Booking.guest_name.ilike(f'%{search}%')) |
            (Booking.id.ilike(f'%{search}%'))
        )
    
    bookings = query.all()
    return render_template('admin_reservations.html', bookings=bookings)

@admin.route('/admin/update-booking-status-bulk', methods=['POST'])
def update_booking_status_bulk():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    booking_id = data.get('booking_id')
    new_status = data.get('status')
    
    booking = Booking.query.get_or_404(booking_id)
    if booking.hotel.admin_id != session['admin_id']:
        return jsonify({'error': 'Unauthorized'}), 401
    
    booking.status = new_status
    db.session.commit()
    return jsonify({'success': True})

@admin.route('/admin/promotions')
def promotions():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    
    conn = sqlite3.connect('instance/booksmart.db')
    cur = conn.cursor()
    
    # Create promotions table if it doesn't exist
    cur.execute('''CREATE TABLE IF NOT EXISTS promotions
                  (id INTEGER PRIMARY KEY AUTOINCREMENT,
                   admin_id INTEGER,
                   name TEXT,
                   type TEXT,
                   value FLOAT,
                   start_date TEXT,
                   end_date TEXT,
                   status TEXT DEFAULT 'active')''')
    conn.commit()
    
    # Fetch promotions for the current admin
    cur.execute("SELECT * FROM promotions WHERE admin_id = ? ORDER BY start_date DESC", (session['admin_id'],))
    promotions = cur.fetchall()
    conn.close()
    
    return render_template('admin_promotions.html', promotions=promotions)

@admin.route('/admin/promotions/create', methods=['POST'])
def create_promotion():
    if 'admin_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    conn = sqlite3.connect('instance/booksmart.db')
    cur = conn.cursor()
    cur.execute('''INSERT INTO promotions 
                   (admin_id, name, type, value, start_date, end_date, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (session['admin_id'], data['name'], data['type'], 
                 float(data['value']), data['start_date'], data['end_date'], 'active'))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@admin.route('/admin/property')
def property():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    return render_template('admin_property.html')

@admin.route('/admin/opportunities')
def opportunities():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    return render_template('admin_opportunities.html')

@admin.route('/admin/inbox')
def inbox():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    return render_template('admin_inbox.html')

@admin.route('/admin/reviews')
def reviews():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    return render_template('admin_reviews.html')

@admin.route('/admin/finance')
def finance():
    if 'admin_id' not in session:
        return redirect(url_for('admin.admin_auth'))
    
    conn = sqlite3.connect('instance/booksmart.db')
    cur = conn.cursor()
    
    # Get today's revenue
    cur.execute('''SELECT SUM(total_amount) FROM bookings 
                   WHERE DATE(created_at) = DATE('now')
                   AND hotel_id IN (SELECT id FROM hotel WHERE admin_id = ?)''',
                (session['admin_id'],))
    today_revenue = cur.fetchone()[0] or 0
    
    # Get monthly revenue
    cur.execute('''SELECT SUM(total_amount) FROM bookings 
                   WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
                   AND hotel_id IN (SELECT id FROM hotel WHERE admin_id = ?)''',
                (session['admin_id'],))
    monthly_revenue = cur.fetchone()[0] or 0
    
    # Get pending payments
    cur.execute('''SELECT SUM(total_amount) FROM bookings 
                   WHERE payment_status = 'pending'
                   AND hotel_id IN (SELECT id FROM hotel WHERE admin_id = ?)''',
                (session['admin_id'],))
    pending_payments = cur.fetchone()[0] or 0
    
    # Get recent transactions
    cur.execute('''SELECT b.*, u.name as guest_name
                   FROM bookings b
                   JOIN users u ON b.user_id = u.id
                   WHERE b.hotel_id IN (SELECT id FROM hotel WHERE admin_id = ?)
                   ORDER BY b.created_at DESC LIMIT 10''',
                (session['admin_id'],))
    transactions = cur.fetchall()
    
    conn.close()
    
    return render_template('admin_finance.html',
                         today_revenue=today_revenue,
                         monthly_revenue=monthly_revenue,
                         pending_payments=pending_payments,
                         transactions=transactions)

@admin.route('/admin/logout')
def logout():
    session.pop('admin_id', None)
    session.pop('admin_email', None)
    flash('Logged out successfully!')
    return redirect(url_for('admin.admin_auth'))