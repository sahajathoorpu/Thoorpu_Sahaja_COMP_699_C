import hashlib
import os
import sqlite3

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from flask_mail import Message

from . import mail

views = Blueprint('views', __name__)

# Hotel database with locations and properties
hotel_database = {
    'new york': [
        {
            'id': 1,
            'name': 'Grand Plaza Hotel',
            'city': 'New York',
            'price': 299,
            'rating': 4.5,
            'reviews': 245,
            'amenities': ['WiFi', 'Pool', 'Spa', 'Restaurant', 'Gym'],
            'image': 'images/hotel 1.jpeg'
        },
        {
            'id': 2,
            'name': 'Times Square Inn',
            'city': 'New York',
            'price': 199,
            'rating': 4.2,
            'reviews': 180,
            'amenities': ['WiFi', 'Restaurant', 'Bar', 'Business Center'],
            'image': 'images/hotel 2.jpeg'
        },
        {
            'id': 3,
            'name': 'Central Park View Hotel',
            'city': 'New York',
            'price': 349,
            'rating': 4.7,
            'reviews': 412,
            'amenities': ['WiFi', 'Spa', 'Restaurant', 'Park View', 'Luxury Suite'],
            'image': 'images/hotel 3.jpeg'
        }
    ],
    'chicago': [
        {
            'id': 12,
            'name': 'Windy City Plaza',
            'city': 'Chicago',
            'price': 279,
            'rating': 4.6,
            'reviews': 320,
            'amenities': ['WiFi', 'Pool', 'Spa', 'Restaurant', 'City View'],
            'image': 'images/hotel 4.jpeg'
        },
        {
            'id': 13,
            'name': 'Magnificent Mile Hotel',
            'city': 'Chicago',
            'price': 329,
            'rating': 4.8,
            'reviews': 450,
            'amenities': ['WiFi', 'Luxury Suite', 'Fine Dining', 'Spa', 'Gym'],
            'image': 'images/hotel 5.jpeg'
        }
    ],
    'san francisco': [
        {
            'id': 14,
            'name': 'Bay View Resort',
            'city': 'San Francisco',
            'price': 399,
            'rating': 4.7,
            'reviews': 380,
            'amenities': ['WiFi', 'Ocean View', 'Restaurant', 'Spa', 'Bar'],
            'image': 'images/hotel 6.jpeg'
        },
        {
            'id': 15,
            'name': 'Golden Gate Inn',
            'city': 'San Francisco',
            'price': 289,
            'rating': 4.4,
            'reviews': 290,
            'amenities': ['WiFi', 'Parking', 'Restaurant', 'Business Center'],
            'image': 'images/hotel 7.jpeg'
        }
    ],
    'las vegas': [
        {
            'id': 4,
            'name': 'Desert Paradise Resort',
            'city': 'Las Vegas',
            'price': 399,
            'rating': 4.8,
            'reviews': 320,
            'amenities': ['WiFi', 'Pool', 'Casino', 'Spa', 'Nightclub'],
            'image': 'images/hotel 8.jpeg'
        },
        {
            'id': 5,
            'name': 'Golden Strip Hotel',
            'city': 'Las Vegas',
            'price': 299,
            'rating': 4.4,
            'reviews': 275,
            'amenities': ['WiFi', 'Casino', 'Shows', 'Buffet', 'Pool'],
            'image': 'images/hotel 9.jpeg'
        }
    ],
    'miami': [
        {
            'id': 6,
            'name': 'Ocean View Resort',
            'city': 'Miami',
            'price': 449,
            'rating': 4.9,
            'reviews': 520,
            'amenities': ['Beach Access', 'Pool', 'Spa', 'Water Sports', 'Fine Dining'],
            'image': 'images/hotel 1.jpeg'
        },
        {
            'id': 7,
            'name': 'South Beach Hotel',
            'city': 'Miami',
            'price': 279,
            'rating': 4.3,
            'reviews': 190,
            'amenities': ['WiFi', 'Beach Club', 'Restaurant', 'Bar', 'Pool'],
            'image': 'images/hotel 2.jpeg'
        }
    ],
    'los angeles': [
        {
            'id': 8,
            'name': 'Hollywood Hills Resort',
            'city': 'Los Angeles',
            'price': 499,
            'rating': 4.6,
            'reviews': 380,
            'amenities': ['Pool', 'Spa', 'Restaurant', 'City View', 'Luxury Suite'],
            'image': 'images/hotel 3.jpeg'
        },
        {
            'id': 9,
            'name': 'Beverly Hills Hotel',
            'city': 'Los Angeles',
            'price': 599,
            'rating': 4.8,
            'reviews': 450,
            'amenities': ['WiFi', 'Pool', 'Spa', 'Fine Dining', 'Concierge'],
            'image': 'images/hotel 4.jpeg'
        }
    ]
}

def init_db():
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                phone TEXT,
                points INTEGER DEFAULT 0
            )
        ''')

        c.execute('''
            CREATE TABLE IF NOT EXISTS saved_hotels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                hotel_id INTEGER,
                saved_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, hotel_id)
            )
        ''')
        conn.commit()
        conn.close()


@views.route('/admin')
def admin_redirect():
    return redirect(url_for('admin.admin_auth'))

@views.route('/')
def home():
    return render_template('index.html')

@views.route('/search')
def search():
    location = request.args.get('location', '')
    checkin = request.args.get('checkin')
    checkout = request.args.get('checkout')
    adults = request.args.get('adults', 1)
    children = request.args.get('children', 0)
    rooms = request.args.get('rooms', 1)

    # Use the global hotel_database
    global hotel_database

    hotels = []
    # Get all hotels first
    hotels = []
    for city_hotels in hotel_database.values():
        hotels.extend(city_hotels)

    # Get filter values
    price_range = request.args.get('price_range')
    rating = request.args.get('rating')
    amenities = request.args.getlist('amenities')

    filtered_hotels = []
    for hotel in hotels:
        matches_filters = True

        # Check price range
        if price_range:
            if '-' in price_range:
                low, high = map(int, price_range.split('-'))
                if not (low <= hotel['price'] <= high):
                    matches_filters = False
            else:
                low = int(price_range.strip('+'))
                if not (hotel['price'] >= low):
                    matches_filters = False

        # Check rating
        if rating and matches_filters:
            min_rating = float(rating)
            if not (hotel['rating'] >= min_rating):
                matches_filters = False

        # Check amenities
        if amenities and matches_filters:
            if not all(amenity in hotel['amenities'] for amenity in amenities):
                matches_filters = False

        # Check location
        if location and matches_filters:
            location_lower = location.lower()
            if not hotel['city'].lower() in location_lower:
                matches_filters = False

        if matches_filters:
            filtered_hotels.append(hotel)

    hotels = filtered_hotels

    # Default hotels for any location not found
    if not hotels and location:
        hotels = [
            {
                'id': 10,
                'name': 'Local Town Hotel',
                'city': location.title(),
                'price': 199,
                'rating': 4.0,
                'reviews': 150,
                'amenities': ['WiFi', 'Restaurant', 'Parking', 'Pool'],
                'image': 'images/hotel-banner.jpg'
            },
            {
                'id': 11,
                'name': 'City Center Inn',
                'city': location.title(),
                'price': 249,
                'rating': 4.2,
                'reviews': 180,
                'amenities': ['WiFi', 'Restaurant', 'Bar', 'Gym'],
                'image': 'images/hotel-banner.jpg'
            }
        ]

    return render_template('search.html', 
                         hotels=hotels,
                         search_params={
                             'location': location,
                             'checkin': checkin,
                             'checkout': checkout,
                             'adults': adults,
                             'children': children,
                             'rooms': rooms
                         })

@views.route('/book/<int:hotel_id>', methods=['GET'])
def book_hotel(hotel_id):
    checkin = request.args.get('checkin')
    checkout = request.args.get('checkout')
    adults = request.args.get('adults', 1)
    children = request.args.get('children', 0)
    rooms = request.args.get('rooms', 1)
    modify_booking_id = request.args.get('modify')

    if modify_booking_id:
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()
        cur.execute("SELECT * FROM bookings WHERE id = ? AND user_id = ?", 
                    (modify_booking_id, session['user_id']))
        booking = cur.fetchone()
        conn.close()

        if booking:
            checkin = booking[3]  # checkin date
            checkout = booking[4]  # checkout date
            rooms = booking[5]    # number of rooms

    # Convert hotel_id to integer since it comes as string from URL
    hotel_id = int(hotel_id)

    # Find hotel in database
    hotel = None
    for city_hotels in hotel_database.values():
        for h in city_hotels:
            if h['id'] == hotel_id:
                hotel = h
                break
        if hotel:
            break

    if not hotel and hotel_id in [10, 11]:
        # Create default hotel if not found
        hotel = {
            'id': hotel_id,
            'name': 'Local Town Hotel' if hotel_id == 10 else 'City Center Inn',
            'city': request.args.get('location', 'Unknown').title(),
            'price': 199 if hotel_id == 10 else 249,
            'rating': 4.0 if hotel_id == 10 else 4.2,
            'reviews': 150 if hotel_id == 10 else 180,
            'amenities': ['WiFi', 'Restaurant', 'Parking', 'Pool'] if hotel_id == 10 else ['WiFi', 'Restaurant', 'Bar', 'Gym'],
            'image': 'images/hotel-banner.jpg'
        }

    if hotel:
        hotel = {
            'id': hotel_id,
            'name': 'Local Town Hotel' if hotel_id == 10 else 'City Center Inn',
            'city': request.args.get('location', 'Unknown').title(),
            'price': 199 if hotel_id == 10 else 249,
            'rating': 4.0 if hotel_id == 10 else 4.2,
            'reviews': 150 if hotel_id == 10 else 180,
            'amenities': ['WiFi', 'Restaurant', 'Parking', 'Pool'] if hotel_id == 10 else ['WiFi', 'Restaurant', 'Bar', 'Gym'],
            'image': 'images/hotel-banner.jpg'
        }
        return render_template('book.html',
                            hotel=hotel,
                            checkin=checkin,
                            checkout=checkout,
                            adults=adults,
                            children=children,
                            rooms=rooms)

    flash('Hotel not found')
    return redirect('/search')

@views.route('/process_payment', methods=['POST'])
def process_payment():
    if 'user_id' not in session:
        flash('Please login to complete your booking')
        return redirect('/login')

    modify_booking_id = request.form.get('modify_booking_id')
    if modify_booking_id:
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()
        cur.execute("DELETE FROM bookings WHERE id = ? AND user_id = ?", 
                    (modify_booking_id, session['user_id']))
        conn.commit()
        conn.close()

    hotel_id = request.form.get('hotel_id')
    checkin = request.form.get('checkin')
    checkout = request.form.get('checkout')
    rooms = request.form.get('rooms')
    payment_method = request.form.get('payment_method')

    if not checkin or not checkout:
        flash('Please select check-in and check-out dates')
        return redirect(request.referrer)

    # Get guest details
    guest_name = request.form.get('guest_name')
    guest_email = request.form.get('guest_email')
    guest_phone = request.form.get('guest_phone')
    special_requests = request.form.get('special_requests')

    if not guest_name or not guest_email or not guest_phone:
        flash('Please provide all required guest information')
        return redirect(f'/book/{hotel_id}?checkin={checkin}&checkout={checkout}&rooms={rooms}')

    # Handle payment based on method
    if payment_method == 'property':
        flash('Booking confirmed! Payment will be collected at the property.')
    else:
        card_name = request.form.get('card_name')
        card_number = request.form.get('card_number')
        if not card_name or not card_number:
            flash('Please provide valid card details')
            return redirect(f'/book/{hotel_id}?checkin={checkin}&checkout={checkout}&rooms={rooms}')

    # Store booking in database (simplified for now)
    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS bookings
                  (id INTEGER PRIMARY KEY AUTOINCREMENT,
                   user_id INTEGER,
                   hotel_id INTEGER,
                   checkin TEXT,
                   checkout TEXT,
                   rooms INTEGER,
                   payment_method TEXT)''')

    cur.execute('''INSERT INTO bookings 
                   (user_id, hotel_id, checkin, checkout, rooms, payment_method)
                   VALUES (?, ?, ?, ?, ?, ?)''',
                (session['user_id'], hotel_id, checkin, checkout, rooms, payment_method))
    conn.commit()
    conn.close()

    # Calculate booking details for receipt
    from datetime import datetime
    booking_date = datetime.now().strftime('%Y-%m-%d')
    checkin_date = datetime.strptime(checkin, '%Y-%m-%d')
    checkout_date = datetime.strptime(checkout, '%Y-%m-%d')
    nights = (checkout_date - checkin_date).days

    # Get hotel details
    hotel = None
    for city_hotels in hotel_database.values():
        for h in city_hotels:
            if h['id'] == int(hotel_id):
                hotel = h
                break
        if hotel:
            break

    if not hotel:
        hotel = {
            'id': int(hotel_id),
            'name': 'Local Town Hotel',
            'city': 'Unknown',
            'price': 199
        }

    total = hotel['price'] * int(rooms) * nights

    # Create booking object for receipt
    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute("SELECT last_insert_rowid()")
    booking_id = cur.fetchone()[0]
    conn.close()

    # Add points for successful booking (100 points) - using the same connection
    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute("UPDATE users SET points = points + 100 WHERE id = ?", (session['user_id'],))
    conn.commit()
    conn.close()

    booking = {
        'id': booking_id,
        'date': booking_date,
        'checkin': checkin,
        'checkout': checkout,
        'rooms': rooms,
        'payment_method': payment_method,
        'nights': nights,
        'total': total
    }

    if payment_method == 'property':
        flash('Booking confirmed! Payment will be collected at the property.')
    else:
        flash('Booking confirmed successfully! You earned 100 points!')

    # If user is logged in, update their booking history
    if 'user_id' in session:
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()
        cur.execute("SELECT points FROM users WHERE id = ?", (session['user_id'],))
        result = cur.fetchone()
        current_points = result[0] if result else 0
        cur.execute("UPDATE users SET points = ? WHERE id = ?", (current_points + 100, session['user_id']))
        conn.commit()
        conn.close()

    return render_template('receipt.html', booking=booking, hotel=hotel)

@views.route('/profile')
def profile():
    user = session.get('user')
    if not user:
        return redirect(url_for('auth.login'))
    return render_template('profile.html', user=user)

@views.route('/earn-points')
def earn_points():
    if 'user_id' not in session:
        return redirect('/login')

    message = request.args.get('message', '')
    return render_template('earn_points.html', message=message)

@views.route('/redeem-points')
def redeem_points():
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute("SELECT points FROM users WHERE id = ?", (user_id,))
    result = cur.fetchone()
    points = result[0] if result else 0
    conn.close()

    return render_template('redeem_points.html', points=points)

@views.route('/payment-methods')
def payment_methods():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS payment_methods
                  (id INTEGER PRIMARY KEY AUTOINCREMENT,
                   user_id INTEGER,
                   card_name TEXT,
                   last_four TEXT,
                   expiry TEXT)''')

    cur.execute("SELECT id, card_name, last_four, expiry FROM payment_methods WHERE user_id = ?", 
                (session['user_id'],))
    payment_methods = cur.fetchall()
    conn.close()

    return render_template('payment_methods.html', payment_methods=payment_methods)

@views.route('/add-payment-method', methods=['POST'])
def add_payment_method():
    if 'user_id' not in session:
        return redirect('/login')

    card_name = request.form['card_name']
    card_number = request.form['card_number']
    expiry = request.form['expiry']

    # Only store last 4 digits for security
    last_four = card_number[-4:] if len(card_number) >= 4 else card_number

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute('''INSERT INTO payment_methods (user_id, card_name, last_four, expiry)
                   VALUES (?, ?, ?, ?)''', 
                (session['user_id'], card_name, last_four, expiry))
    conn.commit()
    conn.close()

    return redirect('/payment-methods')

@views.route('/delete-payment-method/<int:method_id>')
def delete_payment_method(method_id):
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute("DELETE FROM payment_methods WHERE id = ? AND user_id = ?", 
                (method_id, session['user_id']))
    conn.commit()
    conn.close()

    return redirect('/payment-methods')

@views.route('/personal-details')
def personal_details():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('instance/booksmart.db')
    cur = conn.cursor()
    cur.execute("SELECT name, email, phone FROM users WHERE id = ?", (session['user_id'],))
    user = cur.fetchone()
    conn.close()

    if not user:
        return redirect('/login')

    return render_template('personal_details.html', user=user)

@views.route('/update-personal-details', methods=['POST'])
def update_personal_details():
    if 'user_id' not in session:
        return redirect('/login')

    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?", 
                (name, email, phone, session['user_id']))
    conn.commit()
    conn.close()

    return redirect('/personal-details')

@views.route('/booking-history')
def booking_history():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute('''SELECT * FROM bookings 
                   WHERE user_id = ?
                   ORDER BY checkin DESC''', (session['user_id'],))
    bookings = cur.fetchall()
    conn.close()

    from datetime import datetime
    today = datetime.now().strftime('%Y-%m-%d')

    return render_template('booking_history.html', bookings=bookings, today=today)

@views.route('/manage-bookings')
def manage_bookings():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute('''SELECT b.id, b.hotel_id, b.checkin, b.checkout, b.rooms, b.payment_method
                   FROM bookings b
                   WHERE b.user_id = ? AND b.checkin >= date('now')
                   ORDER BY b.checkin''', (session['user_id'],))
    bookings = cur.fetchall()

    # Get hotel details for each booking
    upcoming_bookings = []
    for booking in bookings:
        hotel = None
        for city_hotels in hotel_database.values():
            for h in city_hotels:
                if h['id'] == booking[1]:
                    hotel = h
                    break
            if hotel:
                break

        if not hotel:
            hotel = {
                'name': 'Local Town Hotel',
                'city': 'Unknown'
            }

        upcoming_bookings.append({
            'id': booking[0],
            'hotel': hotel,
            'checkin': booking[2],
            'checkout': booking[3],
            'rooms': booking[4],
            'payment_method': booking[5]
        })

    return render_template('manage_bookings.html', bookings=upcoming_bookings)

@views.route('/cancel-booking/<int:booking_id>')
def cancel_booking(booking_id):
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('users.db')
    cur = conn.cursor()
    cur.execute("DELETE FROM bookings WHERE id = ? AND user_id = ?", 
                (booking_id, session['user_id']))
    conn.commit()
    conn.close()

    flash('Booking cancelled successfully')
    return redirect('/manage-bookings')

@views.route('/packages')
def packages():
    return redirect('/#packages')

@views.route('/reviews')
def reviews():
    if 'user_id' not in session:
        return redirect('/login')
        
    conn = sqlite3.connect('instance/booksmart.db')
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute('''
        SELECT ur.*, h.name as hotel_name 
        FROM user_reviews ur 
        JOIN users u ON ur.user_id = u.id 
        LEFT JOIN hotel_database h ON ur.hotel_id = h.id 
        WHERE ur.user_id = ? 
        ORDER BY ur.date DESC
    ''', (session['user_id'],))
    reviews = cur.fetchall()
    conn.close()
    
    return render_template('reviews.html', reviews=reviews)

@views.route('/referrals')
def referrals():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('referrals.html')

@views.route('/wishlist')
def wishlist():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('wishlist.html')

@views.route('/save_hotel/<int:hotel_id>', methods=['POST'])
def save_hotel(hotel_id):
    if 'user_id' not in session:
        flash('Please login to save hotels')
        return redirect('/login')

    conn = sqlite3.connect('booksmart.db')
    cur = conn.cursor()

    # Create table if not exists
    cur.execute('''CREATE TABLE IF NOT EXISTS saved_hotels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        hotel_id INTEGER,
        saved_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, hotel_id)
    )''')

    try:
        cur.execute("INSERT INTO saved_hotels (user_id, hotel_id) VALUES (?, ?)",
                   (session['user_id'], hotel_id))
        conn.commit()
        flash('Hotel saved successfully!')
    except sqlite3.IntegrityError:
        flash('Hotel already saved!')
    finally:
        conn.close()

    return redirect(request.referrer or url_for('views.search'))

@views.route('/favorites')
def favorites():
    if 'user_id' not in session:
        return redirect('/login')

    conn = sqlite3.connect('booksmart.db')
    cur = conn.cursor()
    cur.execute("""
        SELECT hotel_id FROM saved_hotels 
        WHERE user_id = ?
    """, (session['user_id'],))
    saved_hotel_ids = [row[0] for row in cur.fetchall()]
    conn.close()

    favorite_hotels = []
    for city_hotels in hotel_database.values():
        for hotel in city_hotels:
            if hotel['id'] in saved_hotel_ids:
                favorite_hotels.append(hotel)

    return render_template('favorites.html', hotels=favorite_hotels)

@views.route('/notifications')
def notifications():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('notifications.html')

@views.route('/settings')
def settings():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('settings.html')

@views.route('/help')
def help():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('help.html')

@views.route('/feedback')
def feedback():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('feedback.html')

@views.route('/contact')
def contact():
    return redirect('/#contact')