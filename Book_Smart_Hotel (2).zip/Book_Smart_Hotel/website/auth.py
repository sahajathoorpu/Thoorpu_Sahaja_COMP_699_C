import hashlib

from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from website.models import add_user, get_user_by_email

auth = Blueprint('auth', __name__)


@auth.route('/login', methods=['GET', 'POST'])
def login():
        if request.method == 'POST':
            email = request.form['email']
            password = hashlib.sha256(request.form['password'].encode()).hexdigest()
            user = get_user_by_email(email)
            
            if user:
                if user['password'] == password:
                    session['user'] = dict(user)
                    session['user_id'] = user['id']       
                    session['user_name'] = user['name'] 
                    return redirect(url_for('views.profile'))
                else:
                    flash('Invalid password.')
            else:
                flash('Email not found.')
        return render_template('login.html')


@auth.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()
        
        # Check if user already exists
        existing_user = get_user_by_email(email)
        if existing_user:
            flash('Email already exists. Please use a different email.')
            return render_template('login.html')
            
        try:
            add_user(name, email, password, phone)
            flash('Account created successfully! Please log in.')
            return redirect(url_for('auth.login'))
        except Exception as e:
            flash('An error occurred during registration. Please try again.')
            print(f"Error during registration: {e}")
    return render_template('login.html')

@auth.route('/logout')
def logout():
        session.clear()  # Clears all keys like user_id, user_name, etc.
        return redirect(url_for('auth.login'))

